function r(){const o=new Date,a=o.getFullYear();let t=o.getMonth()+1;t=t<10?`0${t}`:t;let e=o.getDate();return e=e<10?`0${e}`:e,`${a}-${t}-${e}`}export{r as f};
